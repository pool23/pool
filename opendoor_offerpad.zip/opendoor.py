import requests
import json
import datetime
import pandas as pd
list_names = ['phoenix', 'dallas', 'las_vegas', 'atlanta', 'orlando', 'raleigh']
sear_city = []
bath = []
bed = []
price = []
street = []
city = []
state = []
sq_foot = []
sq_ft_price = []

now = datetime.datetime.now()

for names in list_names:
    r = requests.get('https://www.opendoor.com/api/v1/listings/ordered_listings?active=true&market_name=' + str(names))

    counts = json.loads(r.content)
    for i in range(0, len(counts)):
        sear_city.append(counts[i]['address']['market']['identifier'])
        bath.append(counts[i]['bathrooms'])
        bed.append(counts[i]['bedrooms'])
        price.append(int(counts[i]['price_cents']/100))
        street.append(counts[i]['address']['street'])
        city.append(counts[i]['address']['city'])
        state.append(counts[i]['address']['state'])
        sq_foot.append(counts[i]['square_footage'])
        sq_ft_price.append(str(round((int(counts[i]['price_cents']/100)/counts[i]['square_footage']))))

df = pd.DataFrame({'Date': now.strftime("%d/%m/%Y"), 'City': sear_city, 'Bathroom': bath, 'Bedroom': bed,
                   '$': price, 'Address': street, 'Address_city': city, 'State': state, 'Sq_ft': sq_foot,
                   '$Sq/ft(square)': sq_ft_price})
df = df.reindex(
        columns=["Date", "City", "Bathroom", 'Bedroom', '$', 'Address', 'Address_city', 'State', 'Sq_ft',
                 '$Sq/ft(square)'])
df.to_csv('Opendoor.csv'.format(now.strftime("%d_%m_%Y")), index=False)
