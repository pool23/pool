import requests
import json
import datetime
import pandas as pd

sear_city = []
bath = []
bed = []
price = []
street = []
city = []
state = []
county = []
sq_foot = []
zipcode = []
for_sale = []
Access = []

now = datetime.datetime.now()

list_names = ['phoenix', 'tampa', 'orlando', 'atlanta', 'las+vegas', 'south+charlotte%7Ccharlotte']

for names in list_names:
    r = requests.get('https://www.offerpad.com/api/dispositions/web?market=' + str(names))
    counts = json.loads(r.content)
    for i in range(0, len(counts)):
        sear_city.append(counts[i]['market'])
        for_sale.append(counts[i]['status'])
        bath.append(counts[i]['bedrooms'])
        bed.append(counts[i]['bathrooms'])
        price.append(counts[i]['currentListPrice'])
        street.append(counts[i]['streetAddress'])
        city.append(counts[i]['city'])
        county.append(counts[i]['county'])
        state.append(counts[i]['state'])
        zipcode.append(counts[i]['zipCode'])
        sq_foot.append(counts[i]['squareFootage'])
        Access.append(counts[i]['isInstantAccess'])

print(len(sear_city))
print(len(for_sale))
print(len(bath))
print(len(bed))
print(len(price))
print(len(street))
print(len(city))
print(len(state))
print(len(sq_foot))
print(len(zipcode))
print(len(for_sale))
print(len(Access))

df = pd.DataFrame({'Date': now.strftime("%d/%m/%Y"), 'City': sear_city, 'For Sale': for_sale,
                   'Bathroom': bath, 'Bedroom': bed, 'Price($)': price, 'Address': street, 'Address_city': city,
                   'State': state, 'Zipcode': zipcode, 'Sq.ft': sq_foot, 'Access': Access})
df = df.reindex(
        columns=["Date", "City", 'For Sale', "Bathroom", 'Bedroom', 'Price($)', 'Address', 'Address_city', 'State',
                 'Zipcode', 'Sq_ft', 'Access'])
df.to_csv('Offerpad.csv'.format(now.strftime("%d_%m_%Y")), index=False)
