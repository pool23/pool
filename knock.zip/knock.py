#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Purpose: This program scrapes Address, Price, and other details from Knock.com

              ************************************************************************
             #    Author                        Date                Version          #
             # --------------------------------------------------------------------- #
             #  Moody's Analytics            17-4-2018                 V1            #
              ************************************************************************
"""

# importing required libraries
import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime

# taking today date in now variable
now = datetime.datetime.now()

# taking following list
addss = []
bd = []
bh = []
sq_ft = []
city = []
price = []
save = []
cu_city = []

# Two cities are  taken atlanta and charlotte
list_names = ['atlanta', 'charlotte']

# looping over each name
for name in list_names:
    try:
        print("Fetching")
        # trying to make request to get response
        r = requests.get('https://www.knock.com/homes/' + str(name))
        # Finding all divs having information
        box = BeautifulSoup(r.content, 'lxml').find('div', attrs={'class': 'propertyList_57o0v8'})\
            .find_all('a')
        # looping over each div to fetch information
        for i in box:
            # Appending each city name to current city list
            cu_city.append(name)
            print(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                  .find('div', attrs={'class', 'addressLine1_sk7j7f'}).text)
            # Finding Address and appending to address list
            addss.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                         .find('div', attrs={'class', 'addressLine1_sk7j7f'}).text)
            # Finding count for Bed and appending to Bed list
            bd.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                      .find('div', attrs={'class', 'beds_1nh4eon'})
                      .text[0])
            # Finding count for Bathroom and appending to Bathroom list
            bh.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                      .find('div', attrs={'class', 'baths_1nh4eon'})
                      .text[0])
            # Finding Square ft and appending to sq_ft list
            sq_ft.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                         .find('div', attrs={'class', 'size_1nh4eon'}).text)
            # Finding city name and appending to city list
            city.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                        .find('div', attrs={'class', 'city_2zfnvw'})
                         .text)
            # Finding price for each home and appending to price list
            price.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                         .find('div', attrs={'class', 'predictedPrice_x81zoq'}).text)
            # Finding saving option for each home and appending to save list
            save.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                        .find('div', attrs={'class', 'savings_o4635f'})
                         .text.split()[-1])
            print(addss)
    # if try loop fails then print exception as error
    except Exception as e:
        print(e)
    # For pagination in each city
    for page in range(1, 201):
        try:
            if name == 'charlotte' and page == 91:
                break
            a = page * 50
            print(a)
            r = requests.get('https://www.knock.com/homes/' + str(name) + '?limit=50&offset=' + str(a))
            print('https://www.knock.com/homes/' + str(name) + '?limit=50&offset=' + str(a))
            print("fetching pages in pagination")
            box = BeautifulSoup(r.content, 'lxml').find('div', attrs={'class': 'propertyList_57o0v8'})\
                .find_all('a')
            for i in box:
                # Appending each city name to current city list
                cu_city.append(name)
                print(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                      .find('div', attrs={'class', 'addressLine1_sk7j7f'}).text)
                # Finding Address and appending to address list
                addss.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                             .find('div', attrs={'class', 'addressLine1_sk7j7f'}).text)
                # Finding count for Bed and appending to Bed list
                bd.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                          .find('div', attrs={'class', 'beds_1nh4eon'})
                          .text[0])
                # Finding count for Bathroom and appending to Bathroom list
                bh.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                          .find('div', attrs={'class', 'baths_1nh4eon'})
                          .text[0])
                # Finding Square ft and appending to sq_ft list
                sq_ft.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                             .find('div', attrs={'class', 'size_1nh4eon'}).text)
                # Finding city name and appending to city list
                city.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                            .find('div', attrs={'class', 'city_2zfnvw'})
                            .text)
                # Finding price for each home and appending to price list
                price.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                             .find('div', attrs={'class', 'predictedPrice_x81zoq'}).text)
                # Finding saving option for each home and appending to save list
                save.append(i.find('div', attrs={'class', 'infoContainer_1ssg2th'})
                            .find('div', attrs={'class', 'savings_o4635f'})
                            .text.split()[-1])
            print(addss)
        # if try loops fails print exception as error
        except Exception as e:
            print(e)
# print(len(addss))
# print(len(bd))
# print(len(bh))
# print(len(sq_ft))
# print(len(price))
# print(len(save))
# print(len(cu_city))

# Saving it to DataFrame
df = pd.DataFrame({'Date': now.strftime("%d/%m/%Y"), 'City': city, 'Bathroom': bh,
                   'Sq_ft': sq_ft, 'Bedroom': bd, 'Price($)': price, 'Address': addss,
                   'Save': save, 'Current City': cu_city})
# Rearranging columns
df = df.reindex(
        columns=["Date", "Current City", "City", "Bathroom", 'Bedroom', 'Address', 'Price($)',
                 'Sq_ft', 'Save'])
# Saving Output in CSV File
df.to_csv('Knock.csv'.format(now.strftime("%d_%m_%Y")), index=False)
