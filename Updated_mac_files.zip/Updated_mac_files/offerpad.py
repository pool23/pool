#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Purpose: This program scrapes details of selling Property from Opendoor.com

              ************************************************************************
             #    Author                        Date                Version          #
             # --------------------------------------------------------------------- #
             #  Moody's Analytics            20-4-2018                 V2            #
              ************************************************************************
"""
# importing libraries
import requests
import json
import datetime
import pandas as pd
import time

# storing time of execution in start variable
start = time.time()

# Created below lists
sear_city = []
bath = []
bed = []
price = []
street = []
city = []
state = []
county = []
sq_foot = []
zipcode = []
for_sale = []
Access = []

# Taking today's date
now = datetime.datetime.now()

# Created a default list of cities in list_names
list_names = ['phoenix', 'tampa', 'orlando', 'atlanta', 'las+vegas', 'south+charlotte%7Ccharlotte']

# Looping over default list of cities name
for names in list_names:
    # Making a get requests to get response
    r = requests.get('https://www.offerpad.com/api/dispositions/web?market=' + str(names))
    # Loading response content in json object
    counts = json.loads(r.content)
    for i in range(0, len(counts)):
        # Appending search city in sear_city list
        sear_city.append(counts[i]['market'])
        # Appending Status of home in for_sale list
        for_sale.append(counts[i]['status'])
        # Appending number of  bedroom in  bed list
        bed.append(counts[i]['bedrooms'])
        # Appending number of  Bathroom in  bath list
        bath.append(counts[i]['bathrooms'])
        # Appending price of home in price list
        price.append(counts[i]['currentListPrice'])
        # Appending Address in street list
        street.append(counts[i]['streetAddress'])
        # Appending city name in city list
        city.append(counts[i]['city'])
        # Appending country name in county list
        county.append(counts[i]['county'])
        # Appending state name in state list
        state.append(counts[i]['state'])
        # Appending zipcodes in zipcode list
        zipcode.append(counts[i]['zipCode'])
        # Appending square foot in sq_foot list
        sq_foot.append(counts[i]['squareFootage'])
        # Appending access status in access list
        Access.append(counts[i]['isInstantAccess'])

# Printing length of each list
print(len(sear_city))
print(len(for_sale))
print(len(bath))
print(len(bed))
print(len(price))
print(len(street))
print(len(city))
print(len(state))
print(len(sq_foot))
print(len(zipcode))
print(len(for_sale))
print(len(Access))

# Making a DataFrame df and creating following columns with their value
df = pd.DataFrame({'Site': 'OfferPad.com', 'Day': now.strftime("%d"), 'Month': now.strftime('%B'),
                   'Year':  now.strftime('%Y'), 'City': sear_city, 'For Sale': for_sale,
                   'Bathroom': bath, 'Bedroom': bed, 'Price($)': price, 'Address': street, 'Address_city': city,
                   'State': state, 'Zipcode': zipcode, 'Sq_ft': sq_foot, 'Access': Access})
# Rearranging columns according to requirement
df = df.reindex(
        columns=["Site", "Day", "Month", "Year", "City", 'For Sale', "Bathroom", 'Bedroom', 'Price($)',
                 'Address', 'Address_city', 'State', 'Zipcode', 'Sq_ft', 'Access'])
# Saving output in OfferPad Excel
df.to_excel('OfferPad.xlsx'.format(now.strftime("%d_%m_%Y")), index=False)
# Storing the finishing time of program
end = time.time()
# Printing out the  total time of Execution
print("--- %s seconds ---" % (end - start))
