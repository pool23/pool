#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    Purpose: This program scrapes details of selling Property from Opendoor.com

              ************************************************************************
             #    Author                        Date                Version          #
             # --------------------------------------------------------------------- #
             #  Moody's Analytics            20-4-2018                 V2            #
              ************************************************************************
"""
# importing libraries
import requests
import json
import datetime
import pandas as pd
import time

# storing time of execution in start variable
start = time.time()
# Created a default list of cities in list_names
list_names = ['phoenix', 'dallas', 'las_vegas', 'atlanta', 'orlando', 'raleigh']
# Created below lists
sear_city = []
bath = []
bed = []
price = []
street = []
city = []
state = []
sq_foot = []
sq_ft_price = []

# Taking today's date
now = datetime.datetime.now()

# Looping over default list of cities name
for names in list_names:
    # Making a get requests to get response
    r = requests.get('https://www.opendoor.com/api/v1/listings/ordered_listings?active=true&market_name=' + str(names))
    # Loading response content in json
    counts = json.loads(r.content)
    # looping over total length of json object
    for i in range(0, len(counts)):
        # Appending search city in sear_city list
        sear_city.append(counts[i]['address']['market']['identifier'])
        # Appending number of  bathroom in  bath list
        bath.append(counts[i]['bathrooms'])
        # Appending number of  bedroom in  bed list
        bed.append(counts[i]['bedrooms'])
        # Appending price of homes in price list divide by 100 to get the correct value as displayed on the site
        price.append(int(counts[i]['price_cents']/100))
        # Appending Address to street list
        street.append(counts[i]['address']['street'])
        # Appending city name in city list
        city.append(counts[i]['address']['city'])
        # Appending state name in state list
        state.append(counts[i]['address']['state'])
        # Appending square foot detail in sq_foot list
        sq_foot.append(counts[i]['square_footage'])
        # Appending sq_ft price in bathroom in sq_ft_price list
        sq_ft_price.append(str(round((int(counts[i]['price_cents']/100)/counts[i]['square_footage']))))
# Making a DataFrame df and creating following columns with their value
df = pd.DataFrame({'Site': 'Opendoor.com', 'Day': now.strftime("%d"), 'Month': now.strftime('%B'),
                   'Year':  now.strftime('%Y'), 'City': sear_city, 'Bathroom': bath,
                   'Bedroom': bed, '$': price, 'Address': street, 'Address_city': city,
                   'State': state, 'Sq_ft': sq_foot, '$Sq/ft(square)': sq_ft_price})
# Rearranging columns according to requirement
df = df.reindex(
        columns=["Site", "Day", "Month", "Year", "City", "Bathroom", 'Bedroom', '$', 'Address',
                 'Address_city', 'State', 'Sq_ft', '$Sq/ft(square)'])
# Saving output in Opendoor Excel
df.to_excel('Opendoor.xlsx'.format(now.strftime("%d_%m_%Y")), index=False)
# Storing the finishing time of program
end = time.time()
# Printing out the  total time of Execution
print("--- %s seconds ---" % (end - start))
