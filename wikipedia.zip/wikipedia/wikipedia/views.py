from django.shortcuts import render
import pandas as pd
import base64
import matplotlib.pyplot as plt
import os

def Home(request):
    df = pd.read_html('https://en.wikipedia.org/wiki/2018_Winter_Olympics_medal_table')
    print(os.getcwd()+'\\static\\images\\line.png')
    try:
        df[1].ix[22, :] = df[1].ix[22, :].shift(1, axis=0)
        df[1].ix[27, :] = df[1].ix[27, :].shift(1, axis=0)
        df[1].ix[29, :] = df[1].ix[29, :].shift(1, axis=0)
        df[1].ix[30, :] = df[1].ix[30, :].shift(1, axis=0)
        df[1].ix[31, :] = df[1].ix[31, :].shift(1, axis=0)
        df[1].to_csv('wiki_olympic_2018.csv', index=False, header=False)
        dff = pd.read_csv('wiki_olympic_2018.csv')
        dff = dff[:-1]
        dff.plot(x='NOC', y=['Gold', 'Silver', 'Bronze'], kind='line')
        plt.ylim(0, 16)
        plt.savefig(os.getcwd()+'\\static\\images\\line.png')
        dff.plot(x='NOC', y=['Gold', 'Silver', 'Bronze'], kind='bar')
        plt.savefig(os.getcwd()+'\\static\\images\\bar.png')
    except:
        pass



    row = ''
    a = ''
    for k in df[1].values[:1]:
        for td in k:
            a = a + '<th>' + str(td) + '</th>'
    thead = '<thead><tr>'+a+'</tr></thead>'
    for k in df[1].values[1:]:
        a = ''
        for td in k:
            a = a + '<td>' + str(td) + '</td>'
        row = row + '<tr>' + a + '</tr>'
    table = thead+'<tbody>' + row + '</tbody>'

    return render(request, 'index.html', {'table': table})

